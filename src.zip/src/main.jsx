import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import { Route, BrowserRouter, Routes } from "react-router-dom";
import HomePage from "./routes/HomePage.jsx";
import SimplePage from "./routes/SimplePage.jsx";
import MainLayout from "./layouts/MainLayout.jsx";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainLayout />}>
          <Route index element={<HomePage />} />
          <Route path="products" element={<SimplePage title="Products" />} />
          <Route path="customers" element={<SimplePage title="Customers" />} />
          <Route path="careers" element={<SimplePage title="Careers" />} />
          <Route path="demo" element={<SimplePage title="See a demo" />} />
          <Route path="sign-in" element={<SimplePage title="Sign in" />} />
        </Route>
      </Routes>
    </BrowserRouter>
  </StrictMode>,
);
