/**
 * Rounded trapezoid: full-width top, bottom inset on each side, four corner fillets
 * (quadratic beziers, tuned to match ~24px layout rounding).
 */
function clampCornerR(rRaw, w, h, inset, bottomW) {
  return Math.min(
    Math.max(0, rRaw),
    h * 0.4,
    inset * 0.42,
    bottomW > 0 ? bottomW * 0.42 : rRaw,
    w * 0.22
  );
}

export function roundedTrapezoidPathD(w, h, insetRaw, rTopRaw, rBottomRaw) {
  if (w <= 0 || h <= 0) return "";
  const inset = Math.min(Math.max(0, insetRaw), Math.max(0, w / 2 - 1e-3));
  const LDiag = Math.hypot(inset, h);
  if (LDiag < 1e-6) return "";

  const bottomW = Math.max(0, w - 2 * inset);
  const rT = clampCornerR(rTopRaw, w, h, inset, bottomW);
  const rB = clampCornerR(rBottomRaw, w, h, inset, bottomW);

  const ux = inset / LDiag;
  const uy = h / LDiag;

  const tlT = { x: rT, y: 0 };
  const trT = { x: w - rT, y: 0 };
  const trS = { x: w - rT * ux, y: rT * uy };
  const brS = { x: w - inset + rB * ux, y: h - rB * uy };
  const brB = { x: w - inset - rB, y: h };
  const blB = { x: inset + rB, y: h };
  const blS = { x: inset - rB * ux, y: h - rB * uy };
  const tlS = { x: rT * ux, y: rT * uy };

  return [
    `M ${tlT.x} ${tlT.y}`,
    `L ${trT.x} ${trT.y}`,
    `Q ${w} 0 ${trS.x} ${trS.y}`,
    `L ${brS.x} ${brS.y}`,
    `Q ${w - inset} ${h} ${brB.x} ${brB.y}`,
    `L ${blB.x} ${blB.y}`,
    `Q ${inset} ${h} ${blS.x} ${blS.y}`,
    `L ${tlS.x} ${tlS.y}`,
    `Q 0 0 ${tlT.x} ${tlT.y}`,
    "Z",
  ].join(" ");
}
