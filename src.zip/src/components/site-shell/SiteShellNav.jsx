import { Link, useLocation } from "react-router-dom";
import { useLayoutEffect, useState } from "react";
import { roundedTrapezoidPathD } from "./roundedTrapezoidPath.js";

function NavPaperBg({ nav }) {
  const [geom, setGeom] = useState({ w: 0, h: 0, inset: 54, rTop: 24, rBottom: 14 });

  useLayoutEffect(() => {
    if (!nav) return;

    const sync = () => {
      const w = nav.clientWidth;
      const h = nav.clientHeight;
      if (w <= 0 || h <= 0) return;
      const cs = getComputedStyle(nav);
      const inset = parseFloat(cs.getPropertyValue("--nav-trapezoid-inset")) || 0;
      const rTop = parseFloat(cs.getPropertyValue("--nav-corner-radius")) || 24;
      const rBottomParsed = parseFloat(cs.getPropertyValue("--nav-corner-radius-bottom"));
      const rBottom = Number.isFinite(rBottomParsed) ? rBottomParsed : rTop * 0.58;
      setGeom({ w, h, inset, rTop, rBottom });
    };

    const ro = new ResizeObserver(() => sync());
    ro.observe(nav, { box: "border-box" });

    sync();
    let raf1 = 0;
    let raf2 = 0;
    raf1 = requestAnimationFrame(() => {
      sync();
      raf2 = requestAnimationFrame(sync);
    });

    return () => {
      ro.disconnect();
      cancelAnimationFrame(raf1);
      cancelAnimationFrame(raf2);
    };
  }, [nav]);

  const d =
    geom.w > 0 && geom.h > 0
      ? roundedTrapezoidPathD(geom.w, geom.h, geom.inset, geom.rTop, geom.rBottom)
      : "";

  return (
    <svg
      className="site-top-nav-bg site-top-nav-bg-svg"
      aria-hidden
      width="100%"
      height="100%"
      viewBox={`0 0 ${Math.max(geom.w, 1)} ${Math.max(geom.h, 1)}`}
      preserveAspectRatio="none"
    >
      {d ? <path d={d} fill="var(--paper)" /> : null}
    </svg>
  );
}

function NavBrand({ home }) {
  return (
    <Link
      className="site-top-nav-brand site-top-nav-a"
      to="/"
      aria-label="Roxy home"
      aria-current={home ? "page" : undefined}
    >
      <span className="site-roxy-wordmark">Roxy</span>
    </Link>
  );
}

export default function SiteShellNav() {
  const { pathname } = useLocation();
  const home = pathname === "/";
  const [navEl, setNavEl] = useState(null);

  return (
    <div className="site-nav-dock" style={{ transform: "translateX(-50%)" }}>
      <nav
        ref={setNavEl}
        className="site-top-nav site-top-nav-bar"
        aria-label="Main"
      >
        {navEl ? <NavPaperBg nav={navEl} /> : null}

        <div className="site-top-nav-inner">
          <NavBrand home={home} />
        </div>
      </nav>
    </div>
  );
}
