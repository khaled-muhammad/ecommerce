export default function HomePage() {
  return (
    <div className="relative flex min-h-full flex-1 flex-col">
      <section
        className="relative mx-auto flex min-h-[min(70vh,900px)] max-w-[1200px] flex-1 flex-col items-center justify-end gap-6 px-4 pb-16 pt-8 text-center min-[810px]:pb-24"
        aria-label="Hero"
      >

      </section>
    </div>
  );
}
