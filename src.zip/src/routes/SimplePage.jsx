export default function SimplePage({ title }) {
  return (
    <div className="mx-auto max-w-[1200px] px-4 py-16">
      <h1 className="font-ui-medium text-[#0e220e] text-4xl tracking-[-0.03em]">
        {title}
      </h1>
      <p className="font-ui mt-4 max-w-xl text-[15px] leading-[150%] text-[#0e220e]/90">
        Placeholder page — replace with your content.
      </p>
    </div>
  );
}
