import { Outlet } from "react-router-dom";
import SiteShellSprite from "../components/site-shell/SiteShellSprite.jsx";
import SiteShellSafeArea from "../components/site-shell/SiteShellSafeArea.jsx";
import SiteShellNav from "../components/site-shell/SiteShellNav.jsx";
import "./site-shell.css";

const shellStyle = { minHeight: "100vh", width: "auto" };
const canvasStyle = { minHeight: "100vh", width: "auto", display: "contents" };
const heroFill = {
  position: "absolute",
  inset: 0,
  borderRadius: "inherit",
  background: "linear-gradient( #bed2d8, #e9ebed)",
};

export default function MainLayout() {
  return (
    <div className="site-root-vars min-h-full">
      <SiteShellSprite />
      <div className="site-shell site-shell-layout" style={shellStyle}>
        <div
          className="site-canvas site-canvas-width"
          style={canvasStyle}
        >
          <div className="site-hero">
            <div className="site-hero-viewport">
              <div className="site-hero-bg">
                <div className="hero-bg-fill" style={heroFill} aria-hidden />
              </div>
              <div className="site-hero-outlet">
                <Outlet />
              </div>
            </div>
          </div>
        </div>

        <SiteShellSafeArea />
        <SiteShellNav />
      </div>
    </div>
  );
}
